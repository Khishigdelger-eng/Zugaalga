import DisplayData from "./displayData/displayData";
import getData from "./getData/getData";

const modalToglle = document.querySelector("modal-toggle");

const data = new getData();
const view = new DisplayData();
let posts;
data.getData().then((res) => {
  posts = res;
  view.render(posts);
});

setInterval(() => {
  data.getData().then((res) => {
    posts = res;
  });
  view.render(posts.slice(0, 4));
}, 3000);
