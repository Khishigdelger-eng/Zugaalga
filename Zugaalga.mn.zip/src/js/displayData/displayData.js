class DisplayData {
  constructor() {
    this.contentArea = document.querySelector(".popular-post__container");
    this.lastPosts = null;
  }
  clear() {
    this.contentArea.innerHTML = "";
  }
  render(posts) {
    if (this.lastPosts === null) this.lastPosts = posts;
    else {
      posts.map((el) => {
        let i = 0;
        this.lastPosts.map((e) => {
          if (el[0] === e[0]) i++;
        });
        if (i === 0) {
          this.lastPosts.unshift(el);
        }
      });
    }
    this.clear();
    this.lastPosts = this.lastPosts.slice(0, 4);
    this.lastPosts.map((el) => {
      let html = `
        <article class="card">
        <div class="card__photo">
          <img src="${el[1]["URL"]}" alt="${el[1]["title"]}" />
        </div>
        <h1 class="card__title">${el[1]["title"]}</h1>
        <p class="card_desc">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
        </p>
        <button class="card-btn">Бүгдийг үзэх</button>
      </article>
          `;
      this.contentArea.insertAdjacentHTML("beforeend", html);
    });
  }
}

export default DisplayData;
