import axios from "../axios";
require("@babel/polyfill");

class getData {
  async getData() {
    let posts = [];
    await axios
      .get("/posts.json")
      .then((response) => (posts = Object.entries(response.data).reverse()))
      .catch((err) => console.log(err));
    return posts;
  }
}

export default getData;
